"""Module to access VizieR for catalogs containing a source"""
