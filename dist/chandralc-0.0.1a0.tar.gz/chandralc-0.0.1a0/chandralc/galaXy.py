"""This module contains a modified version of the `galaXy` software with updated features."""

import os
import sys
